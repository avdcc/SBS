var filmes;

function preload(){
  filmes = loadStrings("filmes.csv");
}

function aux(string){
	var res;
  for (var i = 0; i< string.length ; i++){
  	if(string[i] != "\""){
    	res.append(string[i]);
    }
  }
  return res;
}

function stripall(list){
	return list.map(x => aux(x));
}

function column(table,ind){
	var res = [];
  for(var i =0; i< table.length ; i++){
  	res += (table[i][ind]);
  }
  return res;
}

function createDic(table){
	dic = [];
  for(var i=0; table[0].length; i++){
  	dic.push({ key: table[0][i],
               value: column(table,i)})
  }
  return dic;
}

function data_imdbid(id,database){
	for(var i=0; i<database.length; i++){
  	if(database[i][5] == id){
    	return database[i];
    }
  }	
}

function List_toSet(List){
	var res = new Set();
  for(var i=0; i<List.length; i++){
  	res.add(List[i]);
  }
  return res;
}

function setup() {
  noCanvas();
  filmes = filmes.map(x => x.replace(/\"/g,"").split(";"));

  print(filmes[0]);
  
  //print(data_imdbid("tt0113326",filmes));
  //print(createDic(filmes));
  //print(Array.from(List_toSet(column(filmes,0))));
  //print(List_toSet(["ola","ole","ola"]));
  var atores = column(filmes,0);
   for(var i=0; i<atores.length; i++){
   	print(atores[i]);
   }
  
}



function draw() {
  background(220);
}